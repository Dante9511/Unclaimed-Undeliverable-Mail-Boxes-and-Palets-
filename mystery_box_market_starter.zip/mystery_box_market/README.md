# Mystery Box Market starter website

## Quick setup on GitHub Pages
1. Create a new GitHub repository. Name it `mystery-box-market` (or any name you want).
2. Upload `index.html` from this folder to the root of the repository.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then Save.
6. Wait a few minutes; GitHub will show your live website URL in the Pages section.

## Before you publish
- Replace `Mystery Box Market` with your business name.
- Replace the sample products and prices in the `products` array inside `index.html`.
- Replace `WHATSAPP_NUMBER` with your WhatsApp number including country code, digits only (no `+`, spaces, or dashes).
- Use photos of the actual items/boxes you have permission to sell.
- Ensure all goods are lawfully acquired and cleared for resale. Don't advertise packages as unclaimed/undeliverable mail unless that status and your right to resell are verified.

This is a static starter storefront. WhatsApp checkout sends the cart as a message; it does not process card payments or store orders. Add a proper payment provider/backend later if needed.
